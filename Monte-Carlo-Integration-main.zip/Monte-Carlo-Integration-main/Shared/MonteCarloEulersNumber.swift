//
//  MonteCarloEulersNumber.swift
//  Monte Carlo Integration
//
//  Created by Whit Castiglioni on 2/17/21.
//

import Foundation
import SwiftUI

class MonteCarloEulersNumber: NSObject, ObservableObject {
    
    var plotDataModel: PlotDataClass? = nil
    
    @Published var insideData = [(xPoint: Double, yPoint: Double)]()
    @Published var outsideData = [(xPoint: Double, yPoint: Double)]()
    @Published var totalGuessesString = ""
    @Published var guessesString = ""
    @Published var eXString = ""
    
    @Published var yMaxPoint = 1.0
    @Published var yMinPoint = 0.0
    @Published var xMaxPoint = 1.0
    @Published var xMinPoint = 0.0

    var domainLimit = 1.0
    @Published var eX = 0.0
    var guesses = 1
    var totalGuesses = 0
    var totalIntegral = 0.0
    
    init(withData data: Bool){
        
        super.init()
        
        insideData = []
        outsideData = []
        
    }


    /// calculate the value of π
    ///
    /// - Calculates the Value of π using Monte Carlo Integration
    ///
    /// - Parameter sender: Any
    func calculateEx() {
        
        var maxGuesses = Double(totalGuesses)
        let boundingBoxCalculator = BoundingBox() ///Instantiates Class needed to calculate the area of the bounding box.
        
        
        maxGuesses = Double(guesses)
        
        totalIntegral = totalIntegral + eulersNumberCalculator(domainLimit: domainLimit, maxGuesses: maxGuesses)
        
        totalGuesses = totalGuesses + guesses
        
        totalGuessesString = "\(totalGuesses)"
        
        ///Calculates the value of π from the area of a unit circle
        
        eX = totalIntegral/Double(totalGuesses) * boundingBoxCalculator.calculateSurfaceArea(numberOfSides: 2, lengthOfSide1: domainLimit, lengthOfSide2: pow(M_E, -1.0 * 0.0 ), lengthOfSide3: 0.0)
        
        eXString = "\(eX)"
        
        //print(eX)
        //print("  "+eXString)
    }

    /// calculates the Monte Carlo Integral of e^x
    ///
    /// - Parameters:
    ///   - maxGuesses: number of guesses to use in the calculaton
    /// - Returns: ratio of points inside to total guesses. Must mulitply by area of box in calling function
 
    ///domainLimit is the right most number you are taking the intergrul from 0. so if if you were to pass 5 the intergrul of e^x is from 0 to 5
    ///
    func eulersNumberCalculator(domainLimit: Double, maxGuesses: Double) ->Double {
        
        var numberOfGuesses = 0.0
        var pointsInRadius = 0.0
        var integral = 0.0
        var point = (xPoint: 0.0, yPoint: 0.0)
        var radiusPoint = 0.0
        let yLimit = pow(M_E, -1.0 * (0.0))
        
        var newInsidePoints : [(xPoint: Double, yPoint: Double)] = []
        var newOutsidePoints : [(xPoint: Double, yPoint: Double)] = []
        
        
        while numberOfGuesses < maxGuesses {
            
            /* Calculate 2 random values within the box */
            /* Determine the distance from that point to the origin */
            /* If the distance is less than the unit radius count the point being within the Unit Circle */
            point.xPoint = Double.random(in: 0...domainLimit)
            point.yPoint = Double.random(in: 0...yLimit)
            
            radiusPoint = point.yPoint
            
            
            // if inside the circle add to the number of points in the radius
            if((pow(M_E, -1.0 * point.xPoint) - radiusPoint) > 0.0){
                pointsInRadius += 1.0
                
                
                newInsidePoints.append(point)
               
            }
            else { //if outside the circle do not add to the number of points in the radius
                
                newOutsidePoints.append(point)
            }
            numberOfGuesses += 1.0
            
            }

        
        integral = Double(pointsInRadius)
        
        //Append the points to the arrays needed for the displays
        //Don't attempt to draw more than 250,000 points to keep the display updating speed reasonable.
        
        if ((totalGuesses < 1000001) || (insideData.count == 0)){
        
            insideData.append(contentsOf: newInsidePoints)
            outsideData.append(contentsOf: newOutsidePoints)
        }
        
        return integral
    }

}
