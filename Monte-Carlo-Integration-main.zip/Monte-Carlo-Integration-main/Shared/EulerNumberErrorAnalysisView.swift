//
//  EulerNumberErrorAnalysisView.swift
//  Monte Carlo Integration
//
//  Created by Whit Castiglioni on 2/18/21.
//

import Foundation
import CorePlot
import SwiftUI


typealias plotDataType = [CPTScatterPlotField : Double]

struct EulerNumberErrorAnalysisView: View {


    
    @EnvironmentObject var plotDataModel :PlotDataClass
    //@ObservedObject private var cosCalculator = Cos_X_Calculator()
    @ObservedObject private var intergrulCalculator = MonteCarloEulersNumber(withData: true)
    @State var xInput: String = "\(Double.pi/2.0)"
    @State var cosOutput: String = "0.0"
    @State var computerCos: String = "\(cos(Double.pi/2.0))"
    @State var error: String = "0.0"
    @State var isChecked:Bool = false
  
    //var to get ploting to work
    @State var totalGuesses = 0.0
    @State var totalIntegral = 0.0
    @State var domainLimit = 1.0
    @State var guessString = "23458"
    @State var totalGuessString = "0"
    @State var eXString = "0.0"

    var body: some View {

        VStack{
      
            CorePlot(dataForPlot: $plotDataModel.plotData, changingPlotParameters: $plotDataModel.changingPlotParameters)
                .setPlotPadding(left: 10)
                .setPlotPadding(right: 10)
                .setPlotPadding(top: 10)
                .setPlotPadding(bottom: 10)
                .padding()
            
            Divider()
            
            HStack{
                
                HStack(alignment: .center) {
                    Text("Expected:")
                        .font(.callout)
                        .bold()
                    //TextField("Expected:", text: $computerCos)
                    //    .padding()
                }.padding()
                
                HStack(alignment: .center) {
                    Text("Error:")
                        .font(.callout)
                        .bold()
                   // TextField("Error", text: $error)
                    //    .padding()
                }.padding()
            
                
            }
            HStack{
                Button("Calculate cos(x)", action: {self.errorSetCalculator()} )
                .padding()
                
                
            }
            
        }
        
    }

    
    
    
    /// calculateCos_X
    /// Function accepts the command to start the calculation from the GUI
    func calculateCos_X(){
        
        let x = Double(xInput)
        xInput = "\(x!)"
        
        var cos_x = 0.0
        let actualcos_x = cos(x!)
        var errorCalc = 0.0
        
        //pass the plotDataModel to the cosCalculator
        //cosCalculator.plotDataModel = self.plotDataModel
        
        //tell the cosCalculator to plot Data or Error
        //cosCalculator.plotError = self.isChecked
        
        
        //Calculate the new plotting data and place in the plotDataModel
        //cos_x = cosCalculator.calculate_cos_x(x: x!)
        

        print("The cos(\(x!)) = \(cos_x)")
        print("computer calcuates \(actualcos_x)")
        
        cosOutput = "\(cos_x)"
        
        computerCos = "\(actualcos_x)"
        
        if(actualcos_x != 0.0){
            
            var numerator = cos_x - actualcos_x
            if(numerator == 0.0) {numerator = 1.0E-16}
            
            errorCalc = log10(abs((numerator)/actualcos_x))
            
        }
        else {
            errorCalc = 0.0
        }
        
        error = "\(errorCalc)"
        
    }
    func errorSetCalculator(){
        let analysisNumbers = [10, 20, 50, 100, 200, 1000, 10000, 50000, 100000, 500000, 1000000, 5000000, 10000000, 50000000 ]
        for i in 0..<analysisNumbers.count {
            //print(analysisNumbers[i])
            intergrulCalculator.guesses = analysisNumbers[i]
            
                        
            let actualEx = 0.6321205588285577

            var errorCalc = 0.0
            
            intergrulCalculator.xMinPoint = 0.0
            intergrulCalculator.xMaxPoint = 1.0
            intergrulCalculator.yMinPoint = 0.0
            intergrulCalculator.yMaxPoint = 1.0
            
            //intergrulCalculator.guesses = Int(guessString)!
            intergrulCalculator.domainLimit = domainLimit
            intergrulCalculator.totalGuesses = Int(totalGuessString) ?? Int(0.0)
            
            intergrulCalculator.calculateEx()
            
            totalGuessString = intergrulCalculator.totalGuessesString
            //pass the plotDataModel to the cosCalculator
            //cosCalculator.plotDataModel = self.plotDataModel
            
            //tell the cosCalculator to plot Data or Error
            //cosCalculator.plotError = self.isChecked
            
            
            //Calculate the new plotting data and place in the plotDataModel
            //cos_x = cosCalculator.calculate_cos_x(x: x!)
            
            //intergrulCalculator.calculateEx()
            let estimateEx = intergrulCalculator.eX
            print("~~")
            print(analysisNumbers[i], estimateEx)
            print(actualEx)
            print("~~")
                //.eulersNumberCalculator(domainLimit: 1.0, maxGuesses: Double(analysisNumbers[i]) )
            

            
            if(actualEx != 0.0){

                
                var numerator = estimateEx - actualEx
                
                if(numerator == 0.0) {numerator = 1.0E-16}
                
                errorCalc = log10(abs((numerator)/actualEx))
                let xPlotPoint = log10( Double( analysisNumbers[i] ) )
                let dataPointInfo: plotDataType = [.X: xPlotPoint, .Y: errorCalc]
                
                //print(dataPoint)
                plotDataModel.appendData(dataPoint: [dataPointInfo])

                
            }
            else {
                errorCalc = 0.0
            }
            
            error = "\(errorCalc)"
            
            
        }
        
    }

   
    
}
////////////////////////////////////////////////////        ///////////////////                 ///////////////////////////////////////     //////////
/////////////////////////////////////////////////////           ////////////////////////            ///////////////////////////         /////////////////////////////////////////////////
/*
func calculate1DInfiniteSum(function: nthTermMultiplierHandler, x: Double, minimum: Int, maximum: Int, firstTerm: Double, isPlotError: Bool, errorType: ErrorHandler, sumOffSet: Double ) -> Double {
    
    
    var plotData :[plotDataType] =  []

    var sum = 0.0
    var previousTerm = firstTerm
    var currentTerm = 0.0
    let lowerIndex = minimum + 1
    
    
    //Deal with the First Point in the Infinite Sum
    
    let errorParameters: [ErrorParameterTuple] = [(n: minimum, x: x, sum: previousTerm)]
    let error = errorType(errorParameters)
    
    plotDataModel!.calculatedText.append("\(minimum), \t\(previousTerm + sumOffSet), \t\(error)\n")
    
    
    if isPlotError {
        
        
        let dataPoint: plotDataType = [.X: Double(1), .Y: (error)]
        plotData.append(contentsOf: [dataPoint])
        
        
    }
    else{
        
        let dataPoint: plotDataType = [.X: Double(minimum), .Y: (previousTerm)]
        plotData.append(contentsOf: [dataPoint])
        
        print("n is \(minimum), x is \(x), currentTerm = \(previousTerm + sumOffSet)")
        
    }
    
    
    
    sum += firstTerm
    
    print(maximum, lowerIndex)

    for n in lowerIndex...maximum {
    
        let parameters: [nthTermParameterTuple] = [(n: n, x: x)]
        
        // Calculate the infinite sum using the function that calculates the multiplier of the nth them in the series from the (n-1)th term.
    
        currentTerm = function(parameters) * previousTerm
        
        print("n is \(n), x is \(x), currentTerm = \(currentTerm)")
        sum += currentTerm
        
        let errorParameters: [ErrorParameterTuple] = [(n: n, x: x, sum: sum)]
        let error = errorType(errorParameters)
        
        plotDataModel!.calculatedText.append("\(n), \t\(sum + sumOffSet), \t\(error)\n")
        
        print("The current ulp of sum is \(sum.ulp)")
        
        previousTerm = currentTerm
        
        if !isPlotError{
            
            print("I am here Jeff")
            
            let dataPoint: plotDataType = [.X: Double(n), .Y: (sum + sumOffSet)]
            
            print(dataPoint)
            plotData.append(contentsOf: [dataPoint])
        }
        else{
            
            print("I should not be here Jeff")
            let dataPoint: plotDataType = [.X: Double(n), .Y: (error)]
            plotData.append(contentsOf: [dataPoint])
            
        }
        
        // Stop the summation when the current term is within machine precision of the total sum.
        
        if (abs(currentTerm) < sum.ulp){
            
            break
        }
    
    
    
    }

    print(plotData)
    plotDataModel!.appendData(dataPoint: plotData)
    return sum


}


*/   ///////////    //////////////  //////////////////          ////////////////////////            ///////////////////         ////////////////////////////////        /////////////////////   //////////////////




//////  ////////////    /////////////   //////////////////////////////  ////////////////////////////////////    /////////////////////////////////

struct EulerNumberErrorAnalysisView_Previews: PreviewProvider {
    static var previews: some View {
        EulerNumberErrorAnalysisView()
    }
}
