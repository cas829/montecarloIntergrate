//
//  Monte_Carlo_IntegrationApp.swift
//  Shared
//
//  Created by Jeff Terry on 12/31/20.
//

import SwiftUI

@main
struct Monte_Carlo_IntegrationApp: App {
    @StateObject var plotDataModel = PlotDataClass(fromLine: true)
    var body: some Scene {
        WindowGroup {
            TabView{
                EulerView()
                    .tabItem {
                        Text("Plottinf e^-x")
                    }
//                ContentView()
//                    .tabItem {
//                        Text("Plotting Circle")
//                    }

                EulerNumberErrorAnalysisView()
                    .environmentObject(plotDataModel)
                    .tabItem {
                        Text("intergrul of e^x error")
                    }
            }
        }
    }
}
//picker exalmple




