//
//  DrawingView.swift
//  Monte Carlo Integration
//
//  Created by Jeff Terry on 12/31/20.
//

import SwiftUI


struct drawingView: View {
    
    @Binding var redLayer : [(xPoint: Double, yPoint: Double)]
    @Binding var blueLayer : [(xPoint: Double, yPoint: Double)]
    @Binding var xMin: Double
    @Binding var xMax: Double
    @Binding var yMin: Double
    @Binding var yMax: Double


    
    var body: some View {
    
        
        ZStack{
        
            drawIntegral(drawingPoints: redLayer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
                .stroke(Color.red)
            //drawIntegral(drawingPoints: redLayer, xMin: xMin , xMax: xMax , yMin: yMin, yMax: yMax )
            //    .stroke(Color.init(red: 0.5, green: 0.20, blue: 0.10))
            //init(Color.RGBColorSpace, red: Double, green: Double, blue: Double, opacity: Double)

            drawIntegral(drawingPoints: blueLayer, xMin: xMin, xMax: xMax , yMin: yMin, yMax: yMax  )
                .stroke(Color.blue)

        }
        .background(Color.white)
        .aspectRatio(1, contentMode: .fill)
        
    }
}

//struct DrawingView_Previews: PreviewProvider {
//
//    @State static var redLayer : [(xPoint: Double, yPoint: Double)] = [(-0.5, 0.5), (0.5, 0.5), (0.0, 0.0), (0.0, 1.0)]
//    @State static var blueLayer : [(xPoint: Double, yPoint: Double)] = [(-0.5, -0.5), (0.5, -0.5), (0.9, 0.0)]
//
//    //@State static var redLayer : [(xPoint: Double, yPoint: Double)] = [(0.0, 1.0), (0.0, 1.0), (0.0, 0.0), (0.0, 1.0)]
//    //@State static var blueLayer : [(xPoint: Double, yPoint: Double)] = [(0.0, 1.0), (0.0, 1.0), (0.9, 0.0)]
//
//    static var previews: some View {
//
//
//        drawingView(redLayer: $redLayer, blueLayer: $blueLayer)
//            .aspectRatio(1, contentMode: .fill)
//            //.drawingGroup()
//
//    }
//}



struct drawIntegral: Shape {

   
    let smoothness : CGFloat = 1.0
    var drawingPoints: [(xPoint: Double, yPoint: Double)]  ///Array of tuples
    
   
    //var orientedDrawingPoints: [(xPoint: Double, yPoint: Double)]
    var xMin: Double
    var xMax: Double
    var yMin: Double
    var yMax: Double
    
     
    //print(xMax)

    func path(in rect: CGRect) -> Path {
        
               
        // draw from the center of our rectangle
        let center = CGPoint(x: rect.width / 2, y: rect.height / 2)
        let scale = rect.width/2
        

        // Create the Path for the display
        
        var path = Path()
        
        for item in drawingPoints {
            //item.xPoint.
            //path.addRect(CGRect(x: item.xPoint*Double(scale)+Double(center.x), y: -1.0 * item.yPoint*Double(scale)+Double(center.y), width: 1.0 , height: 1.0))
           let xNumeratror = ( item.xPoint - xMin ) * Double( rect.width )
           let xDennomerator = ( xMax - xMin )
           let xAns = xNumeratror / xDennomerator
            
           let yTerm1 = Double(rect.height)
            let yT2Numerator = -1.0 * ( Double(rect.height)  ) * ( item.yPoint - yMin )
            let yT2Dennomerator = ( yMax - yMin )
           let yTerm2 = yT2Numerator / yT2Dennomerator
            let yAns = yTerm1 + yTerm2
            
            path.addRect(CGRect(x: xAns , y: yAns , width: 1.0 , height: 1.0))

        }


        return (path)
    }
}
//struct pointConvert
