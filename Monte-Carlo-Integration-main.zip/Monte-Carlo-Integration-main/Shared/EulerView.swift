//
//  EulerView.swift
//  Monte Carlo Integration
//
//  Created by Whit Castiglioni on 2/17/21.
//

import Foundation

import SwiftUI

struct EulerView: View {
    
    //@State var pi = 0.0
    @State var totalGuesses = 0.0
    @State var totalIntegral = 0.0
    @State var domainLimit = 1.0
    @State var guessString = "23458"
    @State var totalGuessString = "0"
    @State var eXString = "0.0"
    
    var plotDataModel: PlotDataClass? = nil

    
    // Setup the GUI to monitor the data from the Monte Carlo Integral Calculator
    @ObservedObject var monteCarlo = MonteCarloEulersNumber(withData: true)
    
    //Setup the GUI View
    var body: some View {
        HStack{
            
            VStack{
                
                VStack(alignment: .center) {
                    Text("Guesses")
                        .font(.callout)
                        .bold()
                    TextField("# Guesses", text: $guessString)
                        .padding()
                }
                .padding(.top, 5.0)
                
                VStack(alignment: .center) {
                    Text("Total Guesses")
                        .font(.callout)
                        .bold()
                    TextField("# Total Guesses", text: $totalGuessString)
                        .padding()
                }
                
                VStack(alignment: .center) {
                    Text("e^x")
                        .font(.callout)
                        .bold()
                    TextField("# e^x", text: $eXString)
                        .padding()
                }
                
                Button("Cycle Calculation", action: {self.calculateEx() })
                    .padding()
                
                Button("Clear", action: {self.clear()})
                    .padding(.bottom, 5.0)
                
                
            }
            .padding()
            
            //DrawingField
            
            
            drawingView(redLayer:$monteCarlo.insideData, blueLayer: $monteCarlo.outsideData, xMin: $monteCarlo.xMinPoint , xMax: $monteCarlo.xMaxPoint , yMin: $monteCarlo.yMinPoint , yMax: $monteCarlo.yMaxPoint )
                .padding()
                .aspectRatio(1, contentMode: .fit)
                .drawingGroup()
            // Stop the window shrinking to zero.
            Spacer()
            
        }
    }
    
    func calculateEx(){
        
        monteCarlo.xMinPoint = 0.0
        monteCarlo.xMaxPoint = 1.0
        monteCarlo.yMinPoint = 0.0
        monteCarlo.yMaxPoint = 1.0
        
        monteCarlo.guesses = Int(guessString)!
        monteCarlo.domainLimit = domainLimit
        monteCarlo.totalGuesses = Int(totalGuessString) ?? Int(0.0)
        
        monteCarlo.calculateEx()
        
        totalGuessString = monteCarlo.totalGuessesString
        
        eXString =  monteCarlo.eXString
        print("  test2:"+eXString)
        
        
        
    }
    
    func clear(){
        
        guessString = "23458"
        totalGuessString = "0.0"
        eXString =  ""
        monteCarlo.totalGuesses = 0
        monteCarlo.totalIntegral = 0.0
        monteCarlo.insideData = []
        monteCarlo.outsideData = []
        
        
    }
    
}

struct EulerView_Previews: PreviewProvider {
    static var previews: some View {
        EulerView()
    }
}
 
